# Opita Page Starter Pack

Paquete base para construir otra pagina con la misma linea visual de Opita Sync.

## Incluye

- `src/components/ui/`: primitives reutilizables.
- `src/components/opita/`: shells y bloques de interfaz de Opita.
- `src/lib/utils.ts`: helper `cn(...)`.
- `src/index.css`: tokens CSS, temas y estilos globales.
- `tailwind.config.ts`: extension de colores, sombras y radios.
- `public/brand/`: lockups y marcas SVG.
- `icons/`: familia de iconos SVG + manifiesto + registro TS.
- `stories/` y `.storybook/`: referencias visuales para reutilizar y adaptar.
- `docs/`: guias de branding y sistema visual.

## Dependencias minimas

- `react`
- `react-dom`
- `tailwindcss`
- `class-variance-authority`
- `clsx`
- `tailwind-merge`
- `@radix-ui/react-slot`
- `lucide-react`

## Notas

- El paquete no incluye backend ni datos mock.
- Los componentes usan aliases de clases y tokens definidos en `src/index.css` y `tailwind.config.ts`.
- `app-shell.tsx` referencia iconos SVG del paquete.
